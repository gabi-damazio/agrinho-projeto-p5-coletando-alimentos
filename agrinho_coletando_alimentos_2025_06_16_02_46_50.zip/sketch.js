let melX, melY, alfaceX, alfaceY;
let carroX, carroY;
let fase = 0; // 0: instrucoes, 1: colheita, 2: transporte, 3: festa, 4: fim de jogo
let pessoasCidade = []; // Armazenará as pessoas na cidade
let melColetado = false;
let alfaceColetado = false;
let velCarro = 8; // Velocidade do carro (Aumentado para dar mais dinamismo)

let progressoColheitaMel = 0; // Progresso da colheita do mel (0 a tempoParaColher)
let progressoColheitaAlface = 0; // Progresso da colheita da alface (0 a tempoParaColher)
let tempoParaColher = 90; // Tempo (em frames) para colher um item (aprox. 1.5 segundos a 60fps)

let balaoX, balaoY; // Posição do balão na fase final
let balaoEstourou = false; // Estado do balão na fase final

let fogosArtificio = []; // Array para armazenar partículas de fogos de artifício
let baloesVoando = []; // Array para armazenar balões pequenos voando
let brilhosExplosao = []; // Array para as novas partículas de brilho e faíscas

// --- Variáveis para Imagens ---
let imgMelPote;
let imgAlface;
let imgFundoCampo; // fundo da fase de colheita (direita - coletar.png)
let imgFundoCampoEsquerdo; // fundo da fase de colheita (esquerda - outrametade.png)
let imgFundoInstrucoes; // fundo da tela de instruções (cenario.png)
let imgPenultimo; // fundo da fase 3 (festa - penultimo.png)
let imgPersonagemBarraca; // Vendedor da barraca (personagembarraca.png)
let imgCenario3; // Nova imagem para o cenário da estrada

// Imagens das pessoas na fila
let imgPessoa1;
let imgPessoa2;
let imgPessoa3;
let imgPessoa4;
let imgPessoa5;

// --- Variáveis para o cenário de transporte (Fase 2) ---
let arvoresOffset = 0; // Movimento horizontal para as árvores
let nuvensOffset = 0; // Movimento horizontal para as nuvens
let asfaltoOffset = 0; // Offset para o movimento do asfalto

// Variáveis para as luzes piscantes do prédio
let prediosPiscandoIndices = [1, 4]; // Dois prédios específicos piscando

let frameCountAtEstouro = 0; // Variável global para capturar o frame do estouro do balão

// --- NOVAS VARIÁVEIS PARA AS MELHORIAS ---
let confetes = []; // Array para armazenar as partículas de confete
let emojisFelizes = []; // Array para armazenar as carinhas felizes
let mostrarMensagemFinal = false; // Controla o surgimento da mensagem final
let alphaMensagemFinal = 0; // Alpha da mensagem final para animação
let ultimaMensagemTempo = 0; // Tempo para controlar a duração da mensagem final

// --- NOVAS VARIÁVEIS PARA MELHORIA DA TELA DE INSTRUÇÕES ---
let botaoIniciarAlpha = 0; // Para animação do botão de iniciar
let botaoIniciarDirecao = 1;

// --- NOVAS VARIÁVEIS PARA A MENSAGEM NO CAMPO ---
let mostrarMensagemCampo = false; // Controla se a mensagem "Ir para a cidade?" aparece
let respostaMensagemCampo = ''; // 'sim', 'nao', ou '' (para sem resposta)
let carroNoCampoVisivel = false; // NOVA VARIÁVEL: Controla a visibilidade do carro no campo

// --- NOVAS VARIÁVEIS PARA A FASE 3 (FESTA) ---
let dialogoBarracaAtivo = false;
let respostaDialogoBarraca = ''; // Armazena a resposta do jogador: 'claro', 'incorreta', 'correta'
let podeDistribuir = false; // Só permite clicar nas pessoas depois da resposta correta
let inputAtivo = false; // Controla se o input de texto está ativo
let textoDigitado = ''; // Armazena o texto que o jogador digita
let mensagemColetadoTempo = 0; // Para mostrar "Coletado!" nos personagens
const MENSAGEM_DURACAO = 60; // Duração da mensagem "Coletado!" em frames
let todasPessoasReceberam = false; // Nova variável para controlar o estado de todas as pessoas
let mostrarBotaoCelebrar = false; // Controla a visibilidade do botão "Clique para Celebrar"
let botaoCelebrarAlpha = 0; // Para animação de fade do botão
let botaoCelebrarDirecao = 1; // Para animação de fade do botão

// Variáveis para a animação da mensagem pós-estouro
let mensagemFinalPosEstouro1 = { alpha: 0, yOffset: 20, chars: [], initialY: 0 };
let mensagemFinalPosEstouro2 = { alpha: 0, yOffset: 20, chars: [], initialY: 0 };
let tempoInicioFadeMensagens = 0;
const DURACAO_FADE_MENSAGENS = 90; // Duração em frames para o fade-in

function preload() {
    // Carregamento de imagens - SEM try...catch, para que o p5.js gerencie a falha de carregamento
    imgMelPote = loadImage('mel pote.png');
    imgAlface = loadImage('alface.png');
    imgFundoCampo = loadImage('coletar.png');
    imgFundoCampoEsquerdo = loadImage('outrametade.png');
    imgFundoInstrucoes = loadImage('cenario.png');
    imgPenultimo = loadImage('penultimo.png');
    imgPersonagemBarraca = loadImage('personagembarraca.png');
    imgPessoa1 = loadImage('primeiro.png');
    imgPessoa2 = loadImage('segunda.png');
    imgPessoa3 = loadImage('terceira.png');
    imgPessoa4 = loadImage('quarta.png');
    imgPessoa5 = loadImage('quinto.png');
    imgCenario3 = loadImage('cenario3.png');
}

function setup() {
    createCanvas(800, 600);
    textAlign(CENTER, CENTER);
    rectMode(CORNER);

    // Posições iniciais dos itens no campo
    melX = width / 4;
    melY = height / 2 - 50;
    alfaceX = width / 4;
    alfaceY = height / 2 + 100;

    // Posição inicial do carro
    carroX = -100;
    carroY = height - 150;

    // Inicializa as pessoas na cidade com as imagens específicas
    let tamanhoPessoaPadrao = 160;
    let alturaPessoaPadrao = 240;

    let imagensPessoasFila = [imgPessoa2, imgPessoa3, imgPessoa1, imgPessoa4, imgPessoa5];

    let basePersonagensY = height * 0.45;

    let distanciaHorizontalEntrePessoas = 69;
    let inicioFilaX = width / 2 - ((imagensPessoasFila.length - 1) / 2) * distanciaHorizontalEntrePessoas - 7;


    for (let i = 0; i < 5; i++) {
        let larguraAtual = tamanhoPessoaPadrao;
        let alturaAtual = alturaPessoaPadrao;

        if (i === 2) {
            larguraAtual = 190;
            alturaAtual = 280;
        }

        pessoasCidade.push({
            x: inicioFilaX + i * distanciaHorizontalEntrePessoas,
            y: basePersonagensY,
            largura: larguraAtual,
            altura: alturaAtual,
            recebeu: false,
            animacaoComerTempo: 0,
            animacaoComerDuracao: 30,
            exibirEmojiTempo: 0,
            exibirEmojiDuracao: 60,
            imagem: imagensPessoasFila[i],
            coletadoAnimacaoTempo: 0 // Novo: para animar "Coletado!"
        });
    }

    // Posição inicial do balão para a fase final
    balaoX = width / 2;
    balaoY = height / 2;
}

function draw() {
    if (fase === 0) {
        desenhaTelaInstrucoes();
    } else if (fase === 1) {
        desenhaCampo();
        atualizaColheita();

        if (melColetado && alfaceColetado) {
            mostrarMensagemCampo = true;
        } else {
            mostrarMensagemCampo = false;
            respostaMensagemCampo = '';
            carroNoCampoVisivel = false;
        }

        if (mostrarMensagemCampo) {
            desenhaMensagemCampo();
        }

        if (carroNoCampoVisivel) {
            let carroDisplayX = width * 0.85;
            let carroDisplayY = height - 120;
            desenhaCarro(carroDisplayX, carroDisplayY, true, 1.3);
            fill(0, 150, 0);
            textSize(18);
            textStyle(BOLD);
            text("Clique para enviar os produtos\naté a cidade!", carroDisplayX - 83, height - 82, 164, 80);
            textStyle(NORMAL);
        }

    } else if (fase === 2) {
        desenhaEstrada();
        moveCarro();

        asfaltoOffset = (asfaltoOffset - velCarro * 1.5) % 80;
        arvoresOffset = (arvoresOffset - velCarro * 0.7) % (width + 200);
        nuvensOffset = (nuvensOffset - velCarro * 0.3) % (width + 100);

        fill(255);
        textSize(24);
        textStyle(BOLD);
        text("O carro está indo em direção à cidade..", width / 2, 40);
        textStyle(NORMAL);

    } else if (fase === 3) {
        desenhaCenarioCidadeFesta();
        desenhaFestaElementos();
        atualizaAnimacoesPessoas();

        // Atualiza a variável todasPessoasReceberam
        todasPessoasReceberam = todasReceberam();

        if (dialogoBarracaAtivo) {
            desenhaDialogoBarraca();
        } else { // Se o diálogo não estiver ativo, mostra a mensagem "Clique no personagem..."
            // Mensagem "Clique no personagem da barraca." em neon
            let neonColor = color(0, 255, 0); // Verde neon
            drawingContext.shadowBlur = 20;
            drawingContext.shadowColor = neonColor;
            fill(neonColor);
            textSize(30);
            textStyle(BOLD);
            text("Clique no personagem da barraca.", width / 2, 40);
            drawingContext.shadowBlur = 0; // Desativa o efeito de sombra
            textStyle(NORMAL);
        }

        // Se todas as pessoas receberam, mostra o botão "Clique para Celebrar"
        if (todasPessoasReceberam) {
            mostrarBotaoCelebrar = true;
            // Animação de alpha para o botão
            botaoCelebrarAlpha += botaoCelebrarDirecao * 3;
            if (botaoCelebrarAlpha > 255 || botaoCelebrarAlpha < 150) {
                botaoCelebrarDirecao *= -1;
                botaoCelebrarAlpha = constrain(botaoCelebrarAlpha, 150, 255);
            }
        } else {
            mostrarBotaoCelebrar = false;
            botaoCelebrarAlpha = 0; // Reseta o alpha se não for para mostrar
        }

        if (mostrarBotaoCelebrar) {
            desenhaBotaoCelebrar();
        }


    } else if (fase === 4) {
        desenhaFimDeJogoCelebracao();
        if (balaoEstourou) {
            atualizaBrilhosExplosao();
            geraFogosArtificio();
            atualizaFogosArtificio();
            geraBaloesVoando();
            atualizaBaloesVoando();
            geraConfetes();
            atualizaConfetes();
            desenhaConfetes();
            geraEmojisFelizes();
            atualizaEmojisFelizes();
            desenhaEmojisFelizes();

            // Animação das mensagens pós-estouro
            let tempoDecorrido = frameCount - tempoInicioFadeMensagens;

            if (tempoDecorrido < DURACAO_FADE_MENSAGENS) {
                let progresso = map(tempoDecorrido, 0, DURACAO_FADE_MENSAGENS, 0, 1);

                // Initialize chars for both messages if not already
                if (mensagemFinalPosEstouro1.chars.length === 0) {
                    let msg1 = "CONEXÃO CELEBRADA COM ALEGRIA!";
                    for (let i = 0; i < msg1.length; i++) {
                        let c = msg1.charAt(i);
                        mensagemFinalPosEstouro1.chars.push({
                            char: c,
                            xOffset: random(-50, 50),
                            yOffset: random(-50, 50),
                            finalXOffset: 0,
                            finalYOffset: 0,
                            color: color(random(255), random(255), random(255)),
                            alpha: 0
                        });
                    }
                    let msg2 = "CAMPO E CIDADE UNIDOS EM FESTA!";
                    for (let i = 0; i < msg2.length; i++) {
                        let c = msg2.charAt(i);
                        mensagemFinalPosEstouro2.chars.push({
                            char: c,
                            xOffset: random(-50, 50),
                            yOffset: random(-50, 50),
                            finalXOffset: 0,
                            finalYOffset: 0,
                            color: color(random(255), random(255), random(255)),
                            alpha: 0
                        });
                    }
                    // Capture initial Y positions
                    mensagemFinalPosEstouro1.initialY = height / 2 - 50;
                    mensagemFinalPosEstouro2.initialY = height / 2;
                }

                // Update character positions and alpha
                textSize(40);
                let currentWidth1 = textWidth("CONEXÃO CELEBRADA COM ALEGRIA!");
                let startX1 = width / 2 - currentWidth1 / 2;

                textSize(30);
                let currentWidth2 = textWidth("CAMPO E CIDADE UNIDOS EM FESTA!");
                let startX2 = width / 2 - currentWidth2 / 2;

                textSize(1); // Set a base size for calculating character widths
                let charSpacing = 0;

                let charCurrentX = startX1;
                for (let i = 0; i < mensagemFinalPosEstouro1.chars.length; i++) {
                    let charData = mensagemFinalPosEstouro1.chars[i];
                    charData.alpha = lerp(0, 255, progresso);
                    charData.xOffset = lerp(charData.xOffset, charData.finalXOffset, progresso);
                    charData.yOffset = lerp(charData.yOffset, charData.finalYOffset, progresso);

                    fill(charData.color.levels[0], charData.color.levels[1], charData.color.levels[2], charData.alpha);
                    textSize(40);
                    textStyle(BOLD);
                    text(charData.char, charCurrentX + charData.xOffset, mensagemFinalPosEstouro1.initialY + charData.yOffset);
                    charCurrentX += textWidth(charData.char);
                }

                charCurrentX = startX2;
                for (let i = 0; i < mensagemFinalPosEstouro2.chars.length; i++) {
                    let charData = mensagemFinalPosEstouro2.chars[i];
                    charData.alpha = lerp(0, 255, progresso);
                    charData.xOffset = lerp(charData.xOffset, charData.finalXOffset, progresso);
                    charData.yOffset = lerp(charData.yOffset, charData.finalYOffset, progresso);

                    fill(charData.color.levels[0], charData.color.levels[1], charData.color.levels[2], charData.alpha);
                    textSize(30);
                    textStyle(BOLD);
                    text(charData.char, charCurrentX + charData.xOffset, mensagemFinalPosEstouro2.initialY + charData.yOffset);
                    charCurrentX += textWidth(charData.char);
                }
                textStyle(NORMAL); // Reset text style

            } else {
                // Once animation is complete, draw normally with final colors
                if (mensagemFinalPosEstouro1.chars.length === 0) { // Should not happen but for safety
                    let msg1 = "CONEXÃO CELEBRADA COM ALEGRIA!";
                    for (let i = 0; i < msg1.length; i++) {
                        mensagemFinalPosEstouro1.chars.push({ char: msg1.charAt(i), xOffset: 0, yOffset: 0, color: color(random(255), random(255), random(255)), alpha: 255 });
                    }
                    let msg2 = "CAMPO E CIDADE UNIDOS EM FESTA!";
                    for (let i = 0; i < msg2.length; i++) {
                        mensagemFinalPosEstouro2.chars.push({ char: msg2.charAt(i), xOffset: 0, yOffset: 0, color: color(random(255), random(255), random(255)), alpha: 255 });
                    }
                    mensagemFinalPosEstouro1.initialY = height / 2 - 50;
                    mensagemFinalPosEstouro2.initialY = height / 2;
                }

                textSize(40);
                let currentWidth1 = textWidth("CONEXÃO CELEBRADA COM ALEGRIA!");
                let startX1 = width / 2 - currentWidth1 / 2;
                let charCurrentX = startX1;
                for (let i = 0; i < mensagemFinalPosEstouro1.chars.length; i++) {
                    let charData = mensagemFinalPosEstouro1.chars[i];
                    fill(charData.color);
                    textSize(40);
                    textStyle(BOLD);
                    text(charData.char, charCurrentX, mensagemFinalPosEstouro1.initialY);
                    charCurrentX += textWidth(charData.char);
                }

                textSize(30);
                let currentWidth2 = textWidth("CAMPO E CIDADE UNIDOS EM FESTA!");
                let startX2 = width / 2 - currentWidth2 / 2;
                charCurrentX = startX2;
                for (let i = 0; i < mensagemFinalPosEstouro2.chars.length; i++) {
                    let charData = mensagemFinalPosEstouro2.chars[i];
                    fill(charData.color);
                    textSize(30);
                    textStyle(BOLD);
                    text(charData.char, charCurrentX, mensagemFinalPosEstouro2.initialY);
                    charCurrentX += textWidth(charData.char);
                }
                textStyle(NORMAL);


            }


            if (frameCount - frameCountAtEstouro > DURACAO_FADE_MENSAGENS + 60) { // Atraso para o botão aparecer
                let restartButtonAlpha = map(frameCount - (frameCountAtEstouro + DURACAO_FADE_MENSAGENS + 60), 0, 90, 0, 255);
                fill(50, 200, 50, restartButtonAlpha); // Cor verde para Reiniciar
                stroke(255, 255, 0, restartButtonAlpha); // Borda amarela para Reiniciar
                strokeWeight(2);
                rect(width / 2 - 100, height - 80, 200, 50, 10);
                fill(255, 255, 255, restartButtonAlpha); // Texto branco para Reiniciar
                textSize(24);
                textStyle(BOLD);
                text("Reiniciar Jogo", width / 2, height - 55);
                textStyle(NORMAL);
                noStroke();
            }

        } else {
            balaoY = height / 2 + sin(frameCount * 0.02) * 20;
            balaoX = width / 2 + cos(frameCount * 0.015) * 15;
        }
    }
}

function mousePressed() {
    if (fase === 0) {
        let dBotao = dist(mouseX, mouseY, width / 2, height / 2 + 80);
        if (dBotao < 37.5) {
            fase = 1;
        }
    } else if (fase === 1 && melColetado && alfaceColetado && mostrarMensagemCampo) {
        let msgCentroX = width / 2;
        let msgCentroY = height * 0.2;
        let btnW = 80;
        let btnH = 40;
        let btnSimX = msgCentroX - 60;
        let btnSimY = msgCentroY + 45;
        let btnNaoX = msgCentroX + 60;
        let btnNaoY = msgCentroY + 45;

        if (mouseX > btnSimX - btnW / 2 && mouseX < btnSimX + btnW / 2 &&
            mouseY > btnSimY - btnH / 2 && mouseY < btnSimY + btnH / 2) {
            respostaMensagemCampo = 'sim';
            carroNoCampoVisivel = true;
        } else if (mouseX > btnNaoX - btnW / 2 && mouseX < btnNaoX + btnW / 2 &&
            mouseY > btnNaoY - btnH / 2 && mouseY < btnNaoY + btnH / 2) {
            respostaMensagemCampo = 'nao';
            carroNoCampoVisivel = false;
        } else if (respostaMensagemCampo === 'sim' && carroNoCampoVisivel) {
            let carroDisplayX = width * 0.85;
            let carroDisplayY = height - 120;
            let dCarro = dist(mouseX, mouseY, carroDisplayX, carroDisplayY);
            if (dCarro < 100) {
                fase = 2;
                arvoresOffset = 0;
                asfaltoOffset = 0;
                nuvensOffset = 0;
                carroX = -100;
                mostrarMensagemCampo = false;
                respostaMensagemCampo = '';
                carroNoCampoVisivel = false;
            }
        }
    } else if (fase === 3) {
        let barracaLargura = 180;
        let barracaAltura = 270;
        let barracaX = width * 0.77;
        let barracaY = height * 0.6;
        let personagemOffsetX = -10;
        let personagemOffsetY = 40;

        // Posição para o clique no personagem da barraca (ajustada para ser mais precisa)
        let personagemClickX = barracaX - barracaLargura / 2 + personagemOffsetX + barracaLargura / 2;
        let personagemClickY = barracaY - barracaAltura + personagemOffsetY + barracaAltura * 0.4; // Ajuste para o centro da cabeça/corpo
        let dPersonagemBarraca = dist(mouseX, mouseY, personagemClickX, personagemClickY);

        if (!dialogoBarracaAtivo && dPersonagemBarraca < 80) { // Raio de clique ajustado
            dialogoBarracaAtivo = true;
            respostaDialogoBarraca = '';
            textoDigitado = ''; // Limpa o texto digitado
            inputAtivo = true; // Ativa o input imediatamente ao clicar no personagem
        } else if (dialogoBarracaAtivo) {
            // Verifica se clicou na área de input do diálogo
            let inputRectX = width / 2 - 100; // Posição do input ajustada para o novo tamanho
            let inputRectY = height * 0.17; // Posição do input, um pouco mais acima (AJUSTADO)
            let inputRectW = 200; // Tamanho diminuído (AJUSTADO)
            let inputRectH = 35; // Tamanho diminuído (AJUSTADO)

            // Se o clique for dentro da caixa de input, ativa
            if (mouseX > inputRectX && mouseX < inputRectX + inputRectW &&
                mouseY > inputRectY && mouseY < inputRectY + inputRectH) {
                inputAtivo = true;
            } else {
                inputAtivo = false;
            }
        }

        if (podeDistribuir) {
            for (let i = 0; i < pessoasCidade.length; i++) {
                let pessoa = pessoasCidade[i];
                let dPessoa = dist(mouseX, mouseY, pessoa.x + pessoa.largura / 2, pessoa.y + pessoa.altura / 2);
                if (dPessoa < max(pessoa.largura, pessoa.altura) / 2 && !pessoa.recebeu) {
                    pessoa.recebeu = true;
                    pessoa.animacaoComerTempo = pessoa.animacaoComerDuracao;
                    pessoa.exibirEmojiTempo = pessoa.exibirEmojiDuracao;
                    pessoa.coletadoAnimacaoTempo = MENSAGEM_DURACAO; // Ativa a animação "Coletado!"
                    break; // Sai do loop após clicar em uma pessoa
                }
            }
        }

        // Verifica o clique no botão de celebração
        if (mostrarBotaoCelebrar && todasPessoasReceberam) {
            let btnW = 60;  // Altura do botão (para rotação)
            let btnH = 150; // Largura do botão (para rotação)
            let btnX = width - btnW / 2 - 20; // X do botão no canto inferior direito (AJUSTADO)
            let btnY = height - btnH / 2 - 20; // Y do botão no canto inferior direito (AJUSTADO)

            // Verifica se o mouse está dentro dos limites do botão
            if (mouseX > btnX - btnW / 2 && mouseX < btnX + btnW / 2 &&
                mouseY > btnY - btnH / 2 && mouseY < btnY + btnH / 2) {
                fase = 4;
                balaoEstourou = false;
                brilhosExplosao = [];
                fogosArtificio = [];
                baloesVoando = [];
                confetes = [];
                emojisFelizes = [];
                // Reinicia as propriedades das mensagens de estouro
                mensagemFinalPosEstouro1 = { alpha: 0, yOffset: 20, chars: [], initialY: 0 };
                mensagemFinalPosEstouro2 = { alpha: 0, yOffset: 20, chars: [], initialY: 0 };
            }
        }


    } else if (fase === 4) {
        let dBalao = dist(mouseX, mouseY, balaoX, balaoY);
        if (dBalao < 80 && !balaoEstourou) {
            balaoEstourou = true;
            frameCountAtEstouro = frameCount;
            geraBrilhosExplosao(balaoX, balaoY, 100);
            tempoInicioFadeMensagens = frameCount; // Captura o tempo de início do fade
        } else if (balaoEstourou && frameCount - frameCountAtEstouro > DURACAO_FADE_MENSAGENS + 60) {
            // Verifica o clique no botão de reiniciar jogo (aparece depois do fade das mensagens)
            let btnX = width / 2 - 100;
            let btnY = height - 80;
            let btnW = 200;
            let btnH = 50;
            if (mouseX > btnX && mouseX < btnX + btnW && mouseY > btnY && mouseY < btnY + btnH) {
                reiniciarJogo();
            }
        }
    }
}

function keyPressed() {
    if (fase === 3 && dialogoBarracaAtivo && inputAtivo) {
        if (keyCode === BACKSPACE) {
            textoDigitado = textoDigitado.substring(0, textoDigitado.length - 1);
        } else if (keyCode === ENTER || keyCode === RETURN) {
            // Processa a resposta quando Enter é pressionado
            if (textoDigitado.toLowerCase().includes("claro")) { // Resposta correta agora é "claro"
                respostaDialogoBarraca = 'correta';
                podeDistribuir = true;
            } else {
                respostaDialogoBarraca = 'incorreta';
                podeDistribuir = false;
            }
            inputAtivo = false; // Desativa o input após a resposta
        } else if (key.length === 1 && key.match(/[a-zA-Z0-9\s]/)) { // Permite letras, números e espaços
            textoDigitado += key;
        }
    }
}


function mouseReleased() {
    if (fase === 1) {
        if (!melColetado) progressoColheitaMel = 0;
        if (!alfaceColetado) progressoColheitaAlface = 0;
    }
}

function atualizaColheita() {
    if (mouseIsPressed) {
        let dMel = dist(mouseX, mouseY, melX, melY);
        if (dMel < 60 && !melColetado) {
            progressoColheitaMel++;
            if (progressoColheitaMel >= tempoParaColher) {
                melColetado = true;
                progressoColheitaMel = 0;
            }
        }

        let dAlface = dist(mouseX, mouseY, alfaceX, alfaceY);
        if (dAlface < 80 && !alfaceColetado) {
            progressoColheitaAlface++;
            if (progressoColheitaAlface >= tempoParaColher) {
                alfaceColetado = true;
                progressoColheitaAlface = 0;
            }
        }
    }
}

function atualizaAnimacoesPessoas() {
    for (let i = 0; i < pessoasCidade.length; i++) {
        let pessoa = pessoasCidade[i];
        if (pessoa.animacaoComerTempo > 0) {
            let progresso = pessoa.animacaoComerTempo / pessoa.animacaoComerDuracao;
            pessoa.yOffset = sin(progresso * PI) * -10;
            pessoa.animacaoComerTempo--;
        } else {
            pessoa.yOffset = 0;
        }
        if (pessoa.exibirEmojiTempo > 0) {
            pessoa.exibirEmojiTempo--;
        }
        // Atualiza a animação de "Coletado!"
        if (pessoa.coletadoAnimacaoTempo > 0) {
            pessoa.coletadoAnimacaoTempo--;
        }
    }
}

function desenhaTelaInstrucoes() {
    if (imgFundoInstrucoes && imgFundoInstrucoes.width > 0) {
        image(imgFundoInstrucoes, 0, 0, width, height);
    } else {
        background(135, 206, 235);
        fill(124, 252, 0);
        rect(0, height * 0.7, width, height * 0.3);
        fill(255, 255, 0);
        ellipse(width * 0.8, height * 0.2, 100, 100);
        fill(255, 255, 255, 200);
        ellipse(width * 0.2, height * 0.15, 80, 50);
        ellipse(width * 0.3, height * 0.25, 90, 60);
    }

    fill(0, 0, 0, 150);
    rect(0, 0, width, height);

    noStroke();
    fill(255);
    textSize(40);
    text("🌱 Festejando a Conexão Campo-Cidade 🏙️", width / 2, height / 3 - 30);

    textSize(30);
    textStyle(BOLD);
    text("Clique para Começar sua Jornada! ", width / 2, height / 2 + 29);
    textStyle(NORMAL);


    botaoIniciarAlpha += botaoIniciarDirecao * 2;
    if (botaoIniciarAlpha > 255 || botaoIniciarAlpha < 100) {
        botaoIniciarDirecao *= -1;
        botaoIniciarAlpha = constrain(botaoIniciarAlpha, 100, 255);
    }

    fill(50, 200, 50, botaoIniciarAlpha);
    noStroke();
    ellipse(width / 2, height / 2 + 80, 75, 75);

    fill(255, 255, 255, botaoIniciarAlpha);
    textSize(19);
    textStyle(BOLD);
    text("INICIAR", width / 2, height / 2 + 80);
    textStyle(NORMAL);

    textSize(16);
    text("Explore a harmonia entre a colheita no campo e a alegria na cidade.", width / 2, height * 2 / 3 + 28);
    text("Ajude a levar os produtos fresquinhos e celebre uma festa inesquecível!", width / 2, height * 2 / 3 + 50);
}

function desenhaCampo() {
    if (imgFundoCampoEsquerdo && imgFundoCampoEsquerdo.width > 0) {
        image(imgFundoCampoEsquerdo, 0, 0, width / 2, height);
    } else {
        fill(100, 180, 0);
        rect(0, 0, width / 2, height);
    }

    if (imgFundoCampo && imgFundoCampo.width > 0) {
        image(imgFundoCampo, width / 2, 0, width / 2, height);
    } else {
        fill(124, 252, 0);
        rect(width / 2, 0, width / 2, height);
    }

    fill(0, 150, 0);
    textSize(36);
    textStyle(BOLD);
    text("Colete o Mel e o Alface!", width / 2, 40);
    textStyle(NORMAL);

    // Mel
    if (imgMelPote && imgMelPote.width > 0) {
        tint(255, melColetado ? 100 : 255);
        image(imgMelPote, melX - 55, melY - 100, 170, 170);
        noTint();
    } else {
        fill(255, 215, 0, melColetado ? 100 : 255);
        ellipse(melX, melY, 60, 60);
    }
    fill(0, 0, 0, melColetado ? 100 : 180);
    textSize(20);
    textStyle(BOLD);
    text("MEL", melX, melY);
    textStyle(NORMAL);
    if (melColetado) {
        fill(0, 150, 0);
        textSize(20);
        text("Coletado!", melX, melY + 60);
    } else {
        stroke(0);
        noFill();
        rect(melX - 30, melY + 40, 60, 10);
        fill(255, 215, 0);
        rect(melX - 30, melY + 40, map(progressoColheitaMel, 0, tempoParaColher, 0, 60), 10);
    }

    // Alface
    if (imgAlface && imgAlface.width > 0) {
        tint(255, alfaceColetado ? 100 : 255);
        image(imgAlface, alfaceX - 100, alfaceY - 149, 219, 249);
        noTint();
    } else {
        fill(0, 128, 0, alfaceColetado ? 100 : 255);
        ellipse(alfaceX, alfaceY, 60, 60);
    }
    fill(0, 0, 0, alfaceColetado ? 100 : 180);
    textSize(20);
    textStyle(BOLD);
    text("ALFACE", alfaceX, alfaceY);
    textStyle(NORMAL);
    if (alfaceColetado) {
        fill(0, 200, 0);
        textSize(20);
        text("Coletado!", alfaceX, alfaceY + 60);
    } else {
        stroke(0);
        noFill();
        rect(alfaceX - 30, alfaceY + 40, 60, 10);
        fill(19, 138, 19);
        rect(alfaceX - 30, alfaceY + 40, map(progressoColheitaAlface, 0, tempoParaColher, 0, 60), 10);
    }
}

function desenhaMensagemCampo() {
    if (!mostrarMensagemCampo) return;

    let msgCentroX = width / 2;
    let msgCentroY = height * 0.2;

    fill(255);
    stroke(0);
    strokeWeight(1);
    rect(msgCentroX - 150, msgCentroY - 60, 300, 150, 15);

    fill(0);
    textSize(22);
    textStyle(NORMAL);
    text("Gostaria de ir para a cidade\nlevar os alimentos?", msgCentroX, msgCentroY - 30);

    let btnW = 80;
    let btnH = 40;
    let btnSimX = msgCentroX - 60;
    let btnSimY = msgCentroY + 45;
    let btnNaoX = msgCentroX + 60;
    let btnNaoY = msgCentroY + 45;

    fill(50, 200, 50);
    rect(btnSimX - btnW / 2, btnSimY - btnH / 2, btnW, btnH, 5);
    fill(255);
    textSize(24);
    textStyle(BOLD);
    text("SIM", btnSimX, btnSimY);

    fill(200, 50, 50);
    rect(btnNaoX - btnW / 2, btnNaoY - btnH / 2, btnW, btnH, 5);
    fill(255);
    textSize(24);
    textStyle(BOLD);
    text("NÃO", btnNaoX, btnNaoY);

    if (respostaMensagemCampo === 'nao') {
        fill(255, 0, 0);
        textSize(20);
        textStyle(BOLD);
        text("A resposta não é essa, a correta é SIM!", msgCentroX, msgCentroY + 95);
    } else if (respostaMensagemCampo === 'sim') {
        fill(50, 150, 50);
        textSize(27);
        textStyle(BOLD);
        text("Agora clique no carro!", msgCentroX, msgCentroY + 105);
    }
    textStyle(NORMAL);
}

function desenhaEstrada() {
    if (imgCenario3 && imgCenario3.width > 0) {
        let imgX = nuvensOffset;
        image(imgCenario3, imgX, 0, width, height);
        image(imgCenario3, imgX + width, 0, width, height);
        if (imgX < -width) {
            nuvensOffset += width;
        }
    } else {
        background(135, 206, 250);
        fill(100);
        rect(0, height * 0.6, width, height * 0.4);
    }

    for (let i = 0; i < 6; i++) {
        let treeX = (i * 200 + arvoresOffset);
        if (treeX < -200) {
            arvoresOffset += 200;
        }

        fill(139, 69, 19);
        rect(treeX + 30, height - 200, 20, 50);

        fill(34, 139, 34);
        ellipse(treeX + 40, height - 200, 70, 70);
        ellipse(treeX + 20, height - 210, 40, 40);
        ellipse(treeX + 60, height - 210, 45, 45);
    }

    fill(70);
    rect(0, height * 0.7, width, height * 0.3);

    stroke(255);
    strokeWeight(8);
    for (let i = -width; i < width * 2; i += 80) {
        line(i + asfaltoOffset, height * 0.85, i + 40 + asfaltoOffset, height * 0.85);
    }
    noStroke();

    desenhaCarro(carroX, carroY, true, 1.5);
}

function moveCarro() {
    carroX += velCarro;
    if (carroX > width + 100) {
        fase = 3;
        carroX = -100;
        dialogoBarracaAtivo = false;
        respostaDialogoBarraca = '';
        podeDistribuir = false;
        inputAtivo = false; // Garante que o input não esteja ativo
        textoDigitado = ''; // Limpa o texto
    }
}

function desenhaCarro(x, y, mostraProdutos = false, escala = 1) {
    push();
    translate(x, y);
    scale(escala);

    let corCarroPrincipal = color(50, 100, 200);
    let corCarroDetalhe = color(80, 150, 250);
    let corVidro = color(150, 200, 255, 180);
    let corFarol = color(255, 255, 150);
    let corLanterna = color(255, 50, 50);

    noStroke();

    fill(0, 0, 0, 50);
    ellipse(0, 45, 150 * escala, 15 * escala);

    fill(corCarroPrincipal);
    rect(-60, 0, 120, 30, 8);

    beginShape();
    vertex(-50, 0);
    vertex(-40, -40);
    bezierVertex(-30, -60, 30, -60, 40, -40);
    vertex(50, 0);
    endShape(CLOSE);

    fill(corCarroDetalhe);
    beginShape();
    vertex(-58, 5);
    vertex(-50, -10);
    bezierVertex(-40, -35, 30, -35, 45, -10);
    vertex(58, 5);
    endShape(CLOSE);

    fill(corVidro);
    beginShape();
    vertex(-38, -35);
    bezierVertex(-30, -50, 30, -50, 38, -35);
    vertex(38, -5);
    vertex(-38, -5);
    endShape(CLOSE);
    rect(-50, -30, 10, 25, 3);
    rect(40, -30, 10, 25, 3);

    fill(corFarol);
    drawingContext.shadowBlur = 15;
    drawingContext.shadowColor = corFarol;
    ellipse(-50, 10, 20, 10);
    ellipse(50, 10, 20, 10);
    drawingContext.shadowBlur = 0;

    fill(40);
    rect(-30, 20, 60, 10, 3);

    fill(corLanterna);
    drawingContext.shadowBlur = 10;
    drawingContext.shadowColor = corLanterna;
    rect(-55, 5, 5, 20, 2);
    rect(50, 5, 5, 20, 2);
    drawingContext.shadowBlur = 0;

    fill(30);
    ellipse(-35, 30, 45, 45);
    ellipse(35, 30, 45, 45);

    fill(80);
    ellipse(-35, 30, 30, 30);
    ellipse(35, 30, 30, 30);

    fill(150);
    ellipse(-35, 30, 15, 15);
    ellipse(35, 30, 15, 15);

    fill(200, 0, 0);
    rect(-38, 28, 5, 8);
    rect(32, 28, 5, 8);

    if (mostraProdutos) {
        noStroke();
        fill(255, 215, 0, 200);
        ellipse(-15, -15, 20, 20);
        fill(0, 128, 0, 200);
        ellipse(15, -15, 25, 25);
    }
    noStroke();

    pop();
}

function desenhaCenarioCidadeFesta() {
    if (imgPenultimo && imgPenultimo.width > 0) {
        image(imgPenultimo, 0, 0, width, height);
    } else {
        background(135, 206, 235);
        fill(80);
        rect(0, height * 0.5, width, height * 0.5);
    }
}

function desenhaFestaElementos() {
    let barracaLargura = 180;
    let barracaAltura = 270;
    let barracaX = width * 0.77;
    let barracaY = height * 0.6;

    if (imgPersonagemBarraca && imgPersonagemBarraca.width > 0) {
        let personagemOffsetX = -10;
        let personagemOffsetY = 40;

        image(imgPersonagemBarraca, barracaX - barracaLargura / 2 + personagemOffsetX, barracaY - barracaAltura + personagemOffsetY, barracaLargura, barracaAltura);
    }

    for (let i = 0; i < pessoasCidade.length; i++) {
        let pessoa = pessoasCidade[i];
        let escalaAnimacao = 1;
        if (pessoa.animacaoComerTempo > 0) {
            let progresso = pessoa.animacaoComerTempo / pessoa.animacaoComerDuracao;
            escalaAnimacao = map(sin(progresso * PI), 0, 1, 0.9, 1.1);
        }

        push();
        translate(pessoa.x + pessoa.largura / 2, pessoa.y + pessoa.altura / 2 + (pessoa.yOffset || 0));
        scale(escalaAnimacao);
        if (pessoa.imagem && pessoa.imagem.width > 0) {
            if (pessoa.recebeu && pessoa.animacaoComerTempo <= 0) {
                tint(255, 150);
            } else {
                noTint();
            }
            image(pessoa.imagem, -pessoa.largura / 2, -pessoa.altura / 2, pessoa.largura, pessoa.altura);
        }
        noTint();
        pop();

        if (pessoa.exibirEmojiTempo > 0) {
            let alpha = map(pessoa.exibirEmojiTempo, 0, pessoa.exibirEmojiDuracao, 0, 255);
            fill(50, 200, 50, alpha);
            textSize(20);
            text("Delicioso!", pessoa.x + pessoa.largura / 2, pessoa.y - 20 - (1 - escalaAnimacao) * 20);
        }

        // Desenha a mensagem "Coletado!"
        if (pessoa.coletadoAnimacaoTempo > 0) {
            let alphaColetado = map(pessoa.coletadoAnimacaoTempo, 0, MENSAGEM_DURACAO, 0, 255);
            fill(255, 255, 0, alphaColetado); // Amarelo com fade
            textSize(22);
            textStyle(BOLD);
            text("Coletado!", pessoa.x + pessoa.largura / 2, pessoa.y - 60 + sin(frameCount * 0.1) * 5); // Animação de flutuação
            textStyle(NORMAL);
        }
    }
}

function desenhaDialogoBarraca() {
    let msgCentroX = width / 2;
    let msgCentroY = height * 0.12; // Balão um pouco mais para cima (AJUSTADO)

    // Balão de fala do personagem da barraca
    fill(255);
    stroke(0);
    strokeWeight(1);
    rect(msgCentroX - 140, msgCentroY - 50, 280, 120, 15); // Balão um pouco menor (AJUSTADO)

    fill(0); // Texto preto
    textSize(20); // Tamanho ajustado
    textStyle(BOLD);
    text("Olá, você gostaria", msgCentroX, msgCentroY - 20); // Mova o texto para dentro do balão (AJUSTADO)
    text("de ganhar Mel e alface?", msgCentroX, msgCentroY + 10); // (AJUSTADO)
    textStyle(NORMAL);

    // Área de Input
    let inputRectX = msgCentroX - 100; // Ajustado para centralizar
    let inputRectY = msgCentroY + 70; // Posição do input, um pouco mais acima (AJUSTADO)
    let inputRectW = 200; // Diminuiu o tamanho (AJUSTADO)
    let inputRectH = 35; // Diminuiu o tamanho (AJUSTADO)

    fill(inputAtivo ? 220 : 200, 220, 255); // Azul claro, mais claro se ativo
    stroke(inputAtivo ? color(0, 0, 255) : color(150)); // Borda azul se ativo, cinza se inativo
    strokeWeight(inputAtivo ? 2 : 1);
    rect(inputRectX, inputRectY, inputRectW, inputRectH, 5);

    fill(0); // Texto do input em preto
    textSize(18); // Tamanho ajustado para o input
    textAlign(LEFT, CENTER); // Alinha o texto à esquerda dentro do input
    // Desenha o texto digitado
    text(textoDigitado + (inputAtivo && frameCount % 30 < 15 ? "|" : ""), inputRectX + 10, inputRectY + inputRectH / 2);
    textAlign(CENTER, CENTER); // Volta ao alinhamento padrão

    // Feedback da resposta (UM POUCO MAIS PARA BAIXO)
    if (respostaDialogoBarraca === 'incorreta') {
        let neonPurple = color(150, 0, 200); // Roxo
        drawingContext.shadowBlur = 15;
        drawingContext.shadowColor = neonPurple;
        fill(neonPurple);
        textSize(20);
        textStyle(BOLD);
        text("Digite a resposta correta:", msgCentroX, inputRectY + inputRectH + 15);
        text("Dica: é uma operadora que não é a TIM.", msgCentroX, inputRectY + inputRectH + 40); // Nova mensagem da dica
        drawingContext.shadowBlur = 0;
        textStyle(NORMAL);
    } else if (respostaDialogoBarraca === 'correta') {
        let neonPurple = color(150, 0, 200); // Roxo
        drawingContext.shadowBlur = 20;
        drawingContext.shadowColor = neonPurple;
        fill(neonPurple);
        textSize(24);
        textStyle(BOLD);
        text("Correto! Agora, clique nas pessoas", msgCentroX, inputRectY + inputRectH + 15);
        text("para ganhar Mel ou alface!", msgCentroX, inputRectY + inputRectH + 40);
        drawingContext.shadowBlur = 0;
        textStyle(NORMAL);
    }
}

function desenhaBotaoCelebrar() {
    let btnW = 60;  // Largura do botão (efetivamente a altura na vertical)
    let btnH = 150; // Altura do botão (efetivamente a largura na vertical)
    let margin = 20; // Margem para o canto inferior direito
    let btnX = width - btnW / 2 - margin; // X do botão no canto inferior direito (AJUSTADO)
    let btnY = height - btnH / 2 - margin; // Y do botão no canto inferior direito (AJUSTADO)

    // Desenho do botão com estilo
    push();
    translate(btnX, btnY);
    rectMode(CENTER);

    let neonColor = color(150, 0, 255, botaoCelebrarAlpha); // Roxo neon com alpha animado
    drawingContext.shadowBlur = 30;
    drawingContext.shadowColor = neonColor;
    fill(neonColor);
    noStroke();
    // Desenha o botão na vertical
    rect(0, 0, btnW, btnH, 15); // Largura e altura invertidas para botão vertical
    drawingContext.shadowBlur = 0;

    fill(0, botaoCelebrarAlpha); // Texto do botão em preto com alpha animado
    textSize(16); // Tamanho da fonte ajustado
    textStyle(BOLD);
    // Texto na horizontal, centralizado dentro do botão vertical
    text("CLIQUE PARA\nCELEBRARMOS A\nCONEXÃO", 0, 0);
    textStyle(NORMAL);

    rectMode(CORNER); // Volta ao modo padrão
    pop();

    // Adiciona uma indicação visual se não puder ser clicado ainda
    if (!todasPessoasReceberam) {
        fill(255, 0, 0, 150); // Camada vermelha translúcida
        push();
        translate(btnX, btnY);
        rectMode(CENTER);
        rect(0, 0, btnW, btnH, 15); // Usa as dimensões invertidas para a sobreposição
        rectMode(CORNER);
        pop();
    }
}

function desenhaFimDeJogoCelebracao() {
    // Gradiente de céu (entardecer/noite)
    let c1 = color(10, 20, 60); // Azul escuro da noite
    let c2 = color(60, 100, 180); // Azul mais claro do crepúsculo
    for (let i = 0; i < height * 0.7; i++) {
        let inter = map(i, 0, height * 0.7, 0, 1);
        let c = lerpColor(c1, c2, inter);
        stroke(c);
        line(0, i, width, i);
    }
    noStroke();

    // Sol/Lua (Poderia ser uma lua ou um sol se pondo, dependendo do mood)
    fill(255, 255, 150);
    drawingContext.shadowBlur = 30;
    drawingContext.shadowColor = color(255, 255, 100, 150);
    ellipse(width * 0.85, height * 0.2, 100, 100);
    drawingContext.shadowBlur = 0;

    // Nuvens
    fill(255, 255, 255, 220);
    drawCloud(width * 0.2, height * 0.15, 150);
    drawCloud(width * 0.5, height * 0.1, 180);
    drawCloud(width * 0.7, height * 0.25, 160);

    // Pássaros mais animados
    fill(20, 20, 20); // Cor mais escura para silhueta noturna
    // Pássaro 1
    push();
    translate(map(sin(frameCount * 0.02), -1, 1, 0, width), height * 0.15 + cos(frameCount * 0.05) * 20);
    rotate(sin(frameCount * 0.1) * 0.1); // Leve inclinação
    drawBird(0, 0);
    pop();
    // Pássaro 2
    push();
    translate(map(cos(frameCount * 0.025), -1, 1, 0, width), height * 0.25 + sin(frameCount * 0.04) * 25);
    rotate(cos(frameCount * 0.12) * 0.1);
    drawBird(0, 0);
    pop();
    // Pássaro 3
    push();
    translate(map(sin(frameCount * 0.015), -1, 1, 0, width), height * 0.1 + cos(frameCount * 0.035) * 15);
    rotate(sin(frameCount * 0.09) * 0.1);
    drawBird(0, 0);
    pop();


    // Grama (mais detalhada)
    fill(50, 100, 30);
    rect(0, height * 0.7, width, height * 0.3);
    // Detalhes da grama
    noStroke();
    for(let i = 0; i < width; i+= random(10,30)) {
        fill(random(40, 60), random(90, 110), random(20, 40), 180);
        ellipse(i, height * 0.7 + random(5, 20), random(3, 8), random(8, 15));
    }


    // Prédios estilizados
    let predios = [
        { x: width * 0.05, y: height * 0.45, w: 70, h: height * 0.25, tipo: 'reto', luzes: true },
        { x: width * 0.16, y: height * 0.50, w: 90, h: height * 0.20, tipo: 'escalonado', luzes: true },
        { x: width * 0.28, y: height * 0.35, w: 80, h: height * 0.35, tipo: 'torre', luzes: true },
        { x: width * 0.4, y: height * 0.55, w: 60, h: height * 0.15, tipo: 'reto', luzes: false },
        { x: width * 0.5, y: height * 0.30, w: 100, h: height * 0.40, tipo: 'reto', luzes: true },
        { x: width * 0.62, y: height * 0.48, w: 75, h: height * 0.22, tipo: 'escalonado', luzes: true },
        { x: width * 0.73, y: height * 0.38, w: 85, h: height * 0.32, tipo: 'torre', luzes: true },
        { x: width * 0.85, y: height * 0.52, w: 50, h: height * 0.18, tipo: 'reto', luzes: false }
    ];

    fill(30, 30, 30, 220); // Cor dos prédios mais escura
    for (let i = 0; i < predios.length; i++) {
        let p = predios[i];

        if (p.tipo === 'escalonado') {
            rect(p.x, p.y + p.h * 0.2, p.w, p.h * 0.8);
            rect(p.x + p.w * 0.1, p.y + p.h * 0.1, p.w * 0.8, p.h * 0.1);
            rect(p.x + p.w * 0.2, p.y, p.w * 0.6, p.h * 0.1);
        } else if (p.tipo === 'torre') {
            rect(p.x + p.w * 0.2, p.y, p.w * 0.6, p.h);
            triangle(p.x + p.w * 0.2, p.y, p.x + p.w * 0.8, p.y, p.x + p.w / 2, p.y - 30);
        } else {
            rect(p.x, p.y, p.w, p.h);
        }

        if (p.luzes) {
            let numJanelasX = floor(p.w / 15);
            let numJanelasY = floor(p.h / 25);
            for (let j = 0; j < numJanelasX; j++) {
                for (let k = 0; k < numJanelasY; k++) {
                    let janelaX = p.x + 5 + j * (p.w / numJanelasX - 5);
                    let janelaY = p.y + 5 + k * (p.h / numJanelasY - 5);

                    let piscaAtivo = false;
                    let ritmoOffset = i * 15 + j * 5 + k * 3; // Ritmo individualizado
                    if ((frameCount + ritmoOffset) % 60 < 30) { // Tempo de ligado/desligado
                        piscaAtivo = true;
                    }

                    if (piscaAtivo) {
                        fill(255, 255, 100, 200); // Amarelo claro
                        drawingContext.shadowBlur = 10;
                        drawingContext.shadowColor = color(255, 255, 50, 150);
                    } else {
                        fill(10, 10, 10, 150); // Janela apagada
                        drawingContext.shadowBlur = 0;
                    }
                    rect(janelaX, janelaY, 8, 12);
                    drawingContext.shadowBlur = 0;
                }
            }
        }
    }


    if (!balaoEstourou) {
        // Balão mais bonito e vermelho vibrante
        fill(255, 50, 50); // Cor principal do balão (vermelho vivo)
        stroke(150, 0, 0); // Contorno mais escuro
        strokeWeight(4); // Contorno mais grosso
        
        // Forma de balão estilizada
        beginShape();
        vertex(balaoX, balaoY - 75); // Top
        bezierVertex(balaoX + 60, balaoY - 75, balaoX + 75, balaoY - 20, balaoX + 75, balaoY); // Right curve
        bezierVertex(balaoX + 75, balaoY + 50, balaoX + 40, balaoY + 75, balaoX, balaoY + 75); // Bottom right curve
        bezierVertex(balaoX - 40, balaoY + 75, balaoX - 75, balaoY + 50, balaoX - 75, balaoY); // Bottom left curve
        bezierVertex(balaoX - 75, balaoY - 20, balaoX - 60, balaoY - 75, balaoX, balaoY - 75); // Left curve
        endShape(CLOSE);

        // Nózinho do balão
        fill(150, 0, 0); // Cor do nó
        triangle(balaoX - 10, balaoY + 75, balaoX + 10, balaoY + 75, balaoX, balaoY + 85);
        
        // Cordão do balão
        stroke(100);
        strokeWeight(1.5);
        line(balaoX, balaoY + 85, balaoX, balaoY + 120);

        noStroke(); // Reset stroke

        // Texto no balão
        fill(255); // Cor do texto dentro do balão
        textSize(25);
        textStyle(BOLD);
        text("CONEXÃO CAMPO & CIDADE\nFORTALECIDA", balaoX, balaoY - 15);
        
        // Texto de instrução para estourar (fora do balão e mais abaixo)
        fill(255, 255, 0); // Amarelo
        textSize(18);
        text("Clique no balão para estourar!", balaoX, balaoY + 140); // Ajustado para fora e mais abaixo
        textStyle(NORMAL);
    } else {
        desenhaBrilhosExplosao();
        desenhaFogosArtificio();
        desenhaBaloesVoando();
    }
}

function drawCloud(x, y, size) {
    ellipse(x, y, size, size * 0.6);
    ellipse(x + size * 0.4, y - size * 0.2, size * 0.7, size * 0.5);
    ellipse(x - size * 0.3, y - size * 0.1, size * 0.5, size * 0.4);
}

function drawBird(x, y) {
    arc(x, y, 20, 20, PI, TWO_PI);
    arc(x + 15, y, 20, 20, PI, TWO_PI);
}


function todasReceberam() {
    for (let i = 0; i < pessoasCidade.length; i++) {
        if (!pessoasCidade[i].recebeu) {
            return false;
        }
    }
    return true;
}

function geraBrilhosExplosao(x, y, num) {
    for (let i = 0; i < num; i++) {
        brilhosExplosao.push({
            x: x,
            y: y,
            vx: random(-5, 5),
            vy: random(-5, 5),
            life: 255,
            size: random(2, 8),
            color: color(random(200, 255), random(150, 255), random(0, 100), 255)
        });
    }
}

function atualizaBrilhosExplosao() {
    for (let i = brilhosExplosao.length - 1; i >= 0; i--) {
        let b = brilhosExplosao[i];
        b.x += b.vx;
        b.y += b.vy;
        b.life -= 10;
        b.vy += 0.2;
        if (b.life <= 0) {
            brilhosExplosao.splice(i, 1);
        }
    }
}

function desenhaBrilhosExplosao() {
    for (let b of brilhosExplosao) {
        noStroke();
        fill(b.color.levels[0], b.color.levels[1], b.color.levels[2], b.life);
        ellipse(b.x, b.y, b.size, b.size);
    }
}

function geraFogosArtificio() {
    // Aumentada a frequência de geração
    if (frameCount % 30 === 0 && fogosArtificio.length < 8) { // Mais fogos simultaneamente
        fogosArtificio.push(new Firework(random(width * 0.1, width * 0.9), height, random(-12, -7))); // Altura e intensidade variadas
    }
}

function atualizaFogosArtificio() {
    for (let i = fogosArtificio.length - 1; i >= 0; i--) {
        fogosArtificio[i].update();
        if (fogosArtificio[i].done()) {
            fogosArtificio.splice(i, 1);
        }
    }
}

function desenhaFogosArtificio() {
    for (let f of fogosArtificio) {
        f.show();
    }
}

class Firework {
    constructor(x, y, vy) {
        this.hu = random(255);
        this.firework = new Particle(x, y, vy, this.hu, true);
        this.exploded = false;
        this.particles = [];
    }

    done() {
        return this.exploded && this.particles.length === 0;
    }

    update() {
        if (!this.exploded) {
            this.firework.applyForce(createVector(0, 0.2));
            this.firework.update();
            if (this.firework.vel.y >= 0) {
                this.exploded = true;
                this.explode();
            }
        }
        for (let i = this.particles.length - 1; i >= 0; i--) {
            this.particles[i].applyForce(createVector(0, 0.2));
            this.particles[i].update();
            if (this.particles[i].done()) {
                this.particles.splice(i, 1);
            }
        }
    }

    explode() {
        for (let i = 0; i < 100; i++) {
            let p = new Particle(this.firework.pos.x, this.firework.pos.y, random(-5, 5), this.hu, false);
            this.particles.push(p);
        }
    }

    show() {
        if (!this.exploded) {
            this.firework.show();
        }
        for (let p of this.particles) {
            p.show();
        }
    }
}

class Particle {
    constructor(x, y, velY, hu, firework) {
        this.pos = createVector(x, y);
        this.firework = firework;
        this.lifespan = 255;
        this.hu = hu;
        if (this.firework) {
            this.vel = createVector(0, velY);
        } else {
            this.vel = p5.Vector.random2D();
            this.vel.mult(random(1, 5));
        }
        this.acc = createVector(0, 0);
    }

    applyForce(force) {
        this.acc.add(force);
    }

    update() {
        if (!this.firework) {
            this.vel.mult(0.9);
            this.lifespan -= 4;
        }
        this.vel.add(this.acc);
        this.pos.add(this.vel);
        this.acc.mult(0);
    }

    done() {
        return this.lifespan < 0;
    }

    show() {
        colorMode(HSB);
        if (!this.firework) {
            strokeWeight(2);
            stroke(this.hu, 255, 255, this.lifespan);
        } else {
            strokeWeight(4);
            stroke(this.hu, 255, 255);
        }
        point(this.pos.x, this.pos.y);
        colorMode(RGB);
    }
}

function geraBaloesVoando() {
    if (frameCount % 40 === 0 && baloesVoando.length < 15) { // Aumenta o número de balões
        baloesVoando.push({
            x: random(width),
            y: height + 50,
            vy: random(-1.5, -4), // Mais rápido para subir
            size: random(25, 60), // Tamanhos variados
            color: color(random(255), random(255), random(255), 200)
        });
    }
}

function atualizaBaloesVoando() {
    for (let i = baloesVoando.length - 1; i >= 0; i--) {
        let b = baloesVoando[i];
        b.y += b.vy;
        b.x += sin(frameCount * 0.05 + i) * 1; // Mais movimento horizontal
        if (b.y < -50) {
            baloesVoando.splice(i, 1);
        }
    }
}

function desenhaBaloesVoando() {
    for (let b of baloesVoando) {
        fill(b.color);
        noStroke();
        ellipse(b.x, b.y, b.size, b.size * 1.3);
        // Desenha um nó mais triangular
        triangle(b.x - b.size * 0.08, b.y + b.size * 0.65, b.x + b.size * 0.08, b.y + b.size * 0.65, b.x, b.y + b.size * 0.75);
        // Corda do balão
        stroke(b.color.levels[0] * 0.5, b.color.levels[1] * 0.5, b.color.levels[2] * 0.5, b.color.levels[3]);
        strokeWeight(1);
        line(b.x, b.y + b.size * 0.75, b.x + random(-10, 10), b.y + b.size * 1.5 + random(-20, 20)); // Corda mais dinâmica
        noStroke();
    }
}

function geraConfetes() {
    // Gera mais confetes por um período mais longo após o estouro
    if (frameCount % 5 === 0 && frameCount - frameCountAtEstouro < 360) { // Gera por 6 segundos
        let numConfetes = 8; // Mais confetes por frame
        for (let i = 0; i < numConfetes; i++) {
            confetes.push({
                x: random(0, width), // Confetes vêm de toda a tela
                y: random(0, -50), // Começam acima da tela
                vx: random(-2, 2),
                vy: random(1, 4), // Caem para baixo
                rot: random(TWO_PI),
                rotSpeed: random(-0.1, 0.1),
                size: random(5, 15),
                color: color(random(255), random(255), random(255))
            });
        }
    }
}

function atualizaConfetes() {
    for (let i = confetes.length - 1; i >= 0; i--) {
        let c = confetes[i];
        c.x += c.vx;
        c.y += c.vy;
        c.vy += 0.2; // Gravidade
        c.rot += c.rotSpeed;
        if (c.y > height + 20) {
            confetes.splice(i, 1);
        }
    }
}

function desenhaConfetes() {
    for (let c of confetes) {
        push();
        translate(c.x, c.y);
        rotate(c.rot);
        fill(c.color);
        noStroke();
        rectMode(CENTER); // Desenha o confete do centro
        rect(0, 0, c.size, c.size);
        pop();
    }
}

function geraEmojisFelizes() {
    // Gera mais emojis por um período mais longo após o estouro
    if (frameCount % 20 === 0 && frameCount - frameCountAtEstouro < 420) { // Gera por 7 segundos
        emojisFelizes.push({
            x: random(width * 0.1, width * 0.9), // Emojis de toda a largura da tela
            y: height + 20,
            vy: random(-2, -6), // Mais rápido para subir
            life: 255,
            size: random(30, 60), // Tamanhos variados
            vx_ondulacao: random(-1, 1) // Para movimento horizontal suave
        });
    }
}

function atualizaEmojisFelizes() {
    for (let i = emojisFelizes.length - 1; i >= 0; i--) {
        let e = emojisFelizes[i];
        e.y += e.vy;
        e.x += e.vx_ondulacao + sin(frameCount * 0.08 + i) * 0.8; // Movimento horizontal ondulatório mais pronunciado
        e.life -= 3;
        if (e.life <= 0) {
            emojisFelizes.splice(i, 1);
        }
    }
}

function desenhaEmojisFelizes() {
    for (let e of emojisFelizes) {
        fill(255, 255, 0, e.life); // Cor amarela para o emoji
        noStroke();
        ellipse(e.x, e.y, e.size);

        // Olhos
        fill(0, 0, 0, e.life);
        ellipse(e.x - e.size * 0.15, e.y - e.size * 0.15, e.size * 0.1, e.size * 0.15); // Olhos ovais
        ellipse(e.x + e.size * 0.15, e.y - e.size * 0.15, e.size * 0.1, e.size * 0.15);

        // Boca (sorriso mais feliz)
        arc(e.x, e.y + e.size * 0.15, e.size * 0.5, e.size * 0.3, 0, PI);
        // Bochechas (opcional, para mais fofura)
        fill(255, 150, 150, e.life * 0.5); // Rosa claro para bochechas
        ellipse(e.x - e.size * 0.25, e.y + e.size * 0.05, e.size * 0.15);
        ellipse(e.x + e.size * 0.25, e.y + e.size * 0.05, e.size * 0.15);
    }
}


function reiniciarJogo() {
    melColetado = false;
    alfaceColetado = false;
    progressoColheitaMel = 0;
    progressoColheitaAlface = 0;
    carroX = -100;
    fase = 0;

    for (let i = 0; i < pessoasCidade.length; i++) {
        pessoasCidade[i].recebeu = false;
        pessoasCidade[i].animacaoComerTempo = 0;
        pessoasCidade[i].exibirEmojiTempo = 0;
        pessoasCidade[i].coletadoAnimacaoTempo = 0;
    }

    balaoEstourou = false;
    brilhosExplosao = [];
    fogosArtificio = [];
    baloesVoando = [];
    confetes = [];
    emojisFelizes = [];
    
    // Reinicia as variáveis de controle da mensagem final
    mensagemFinalPosEstouro1 = { alpha: 0, yOffset: 20, chars: [], initialY: 0 };
    mensagemFinalPosEstouro2 = { alpha: 0, yOffset: 20, chars: [], initialY: 0 };
    tempoInicioFadeMensagens = 0;

    dialogoBarracaAtivo = false;
    respostaDialogoBarraca = '';
    podeDistribuir = false;
    inputAtivo = false;
    textoDigitado = '';
    mostrarBotaoCelebrar = false;
    botaoCelebrarAlpha = 0;
    botaoCelebrarDirecao = 1;

    mostrarMensagemCampo = false;
    respostaMensagemCampo = '';
    carroNoCampoVisivel = false;
    todasPessoasReceberam = false;
}